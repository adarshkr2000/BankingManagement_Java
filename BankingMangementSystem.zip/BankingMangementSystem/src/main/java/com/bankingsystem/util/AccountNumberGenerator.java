//package com.bankingsystem.util;
//
//import java.util.Random;
//
//public class AccountNumberGenerator {
//
//    // Method to generate a unique account number
//    public static String generate(String phoneNumber, String dateOfBirth) {
//        // Check if dateOfBirth is null or empty
//        if (dateOfBirth == null || dateOfBirth.isEmpty() || dateOfBirth.length() < 10) {
//            // Handle the error, e.g., log it or return a default value
//            return "Invalid Date of Birth";
//        }
//
//        // Extract last 4 digits of phone number
//        String phoneSuffix = phoneNumber.substring(phoneNumber.length() - 4);
//
//        // Extract year from date of birth (assuming format is YYYY-MM-DD)
//        String birthYear = dateOfBirth.substring(0, 4);
//
//        // Generate a random 2-digit number for uniqueness
//        Random random = new Random();
//        int randomDigits = random.nextInt(90) + 10; // Range: 10 to 99
//
//        // Combine to form a 10-digit account number
//        return birthYear + phoneSuffix + randomDigits;
//    }
//}
