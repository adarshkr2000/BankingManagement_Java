package com.bankingsystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // Static variable to hold the connection
    private static Connection connection;

    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String USER = "root";
    private static final String PASSWORD = "Javaservelet@20";

    // Synchronized method to ensure thread-safety
    public static synchronized Connection getConnection() throws SQLException {
        try {
            // Check if the connection is null or closed
            if (connection == null || connection.isClosed()) {
                // Register the MySQL driver (optional for modern JDBC, but ensures compatibility)
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the connection to the database
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("MySQL Driver not found.", e);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error establishing database connection", e);
        }

        // Return the connection
        return connection;
    }

    // Method to explicitly close the connection if needed (optional but useful for cleanup)
    public static synchronized void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                connection = null; // Reset to ensure it can be reopened later
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
