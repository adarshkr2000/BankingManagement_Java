package com.banking.model;

public class AccountList {
    private double id;
    private String username;
    private String dateofbirth;
    private String email;
    private String accountNumber;
    private String accountHolderName;
    private String accountType;
    private double balance;
    
	public double getId() {
		return id;
	}
	public void setId(double id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dob) {
		this.dateofbirth = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

    // Getters and Setters
    
}
