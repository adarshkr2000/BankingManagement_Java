package com.banking.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.banking.model.Transaction;

public class TransactionDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Javaservelet@20";

    // Method to insert a new transaction record into the transactions table
    public boolean recordTransaction(String fromAccount, String toAccount, double amount, String description) {
        String query = "INSERT INTO transactions (from_account, to_account, amount, description) " +
                       "VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, fromAccount);
            stmt.setString(2, toAccount);
            stmt.setDouble(3, amount);
            stmt.setString(4, description);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to retrieve the last inserted transaction ID (for status update later)
    public int getLastTransactionId() {
        String query = "SELECT LAST_INSERT_ID()";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Return -1 if no transaction found
    }

    // Method to update the status of a transaction (e.g., 'COMPLETED' or 'FAILED')
    public boolean updateTransactionStatus(int transactionId, String status) {
        String query = "UPDATE transactions SET status = ? WHERE transaction_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, status);
            stmt.setInt(2, transactionId);

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    // Method to retrieve all transactions from the database
    public List<Transaction> getAllTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT transaction_id, from_account, to_account, amount, description, transaction_date FROM transactions";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setFromAccount(rs.getString("from_account"));
                transaction.setToAccount(rs.getString("to_account"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setDescription(rs.getString("description"));
                transaction.setTransactionDate(rs.getTimestamp("transaction_date"));

                transactions.add(transaction);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return transactions;
    }

  
}
