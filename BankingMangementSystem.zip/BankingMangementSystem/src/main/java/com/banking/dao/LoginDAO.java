package com.banking.dao;

import com.banking.model.AccountDetails;
import com.banking.model.Login;
import com.banking.model.Registration;
import com.bankingsystem.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {
	// Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String USER = "root";
    private static final String PASSWORD = "Javaservelet@20";

	  public static AccountDetails validateUser(String accountNumber, String password) {
	        String query = "SELECT * FROM users WHERE account_number = ? AND password = ?";
	        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement statement = connection.prepareStatement(query)) {

	            statement.setString(1, accountNumber);
	            statement.setString(2, password);

	            ResultSet rs = statement.executeQuery();
	            if (rs.next()) {
	                AccountDetails accountDetails = new AccountDetails();
                    accountDetails.setId(rs.getInt("id"));
                    accountDetails.setUsername(rs.getString("username"));
                    accountDetails.setEmail(rs.getString("email"));
                    accountDetails.setAccountHolderName(rs.getString("account_holder_name"));
                    accountDetails.setDateOfBirth(rs.getDate("date_of_birth").toLocalDate());
                    accountDetails.setPhoneNumber(rs.getString("phone_number"));
                    accountDetails.setAccountType(rs.getString("account_type"));
                    accountDetails.setBalance(rs.getDouble("balance"));
                    accountDetails.setAccountNumber(rs.getString("account_number"));
	                return accountDetails;
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
}
