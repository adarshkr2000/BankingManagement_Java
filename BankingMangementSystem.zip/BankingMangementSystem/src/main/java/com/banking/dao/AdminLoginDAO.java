package com.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.banking.model.AdminModel;
import com.bankingsystem.util.DatabaseConnection;

public class AdminLoginDAO {
    
    // Validate admin login
    public AdminModel validateAdminLogin(String username, String password) {
        boolean isValid = false;
        
        String query = "SELECT * FROM admin WHERE username = ? AND password = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
            	 AdminModel adminModel = new AdminModel();
                 adminModel.setUsername(rs.getString("username"));
                 adminModel.setPassword(rs.getString("password"));
                 return adminModel;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
}
