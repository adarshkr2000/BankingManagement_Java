package com.banking.dao;

import com.banking.model.AccountDetails;
import com.banking.model.AccountList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountListDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Javaservelet@20";

    // Method to get all account details
    public List<AccountList> getAllAccounts() {
        List<AccountList> accounts = new ArrayList<>();
        String query = "SELECT * FROM users";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                AccountList account = new AccountList();
                account.setId(rs.getDouble("id"));
                account.setUsername(rs.getString("username"));
                account.setDateofbirth(rs.getString("date_of_birth"));
                account.setEmail(rs.getString("email"));
                account.setAccountNumber(rs.getString("account_number"));
                account.setAccountHolderName(rs.getString("account_holder_name"));
                account.setAccountType(rs.getString("account_type"));
                account.setBalance(rs.getDouble("balance"));
                accounts.add(account);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return accounts;
    }
    ///delete
    
    public boolean deleteAccount(String accountNumber) {
        String query = "DELETE FROM users WHERE account_number = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, accountNumber);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;  // Return true if account is deleted
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  
    }
    
    // method to get account by account number
    public AccountDetails getAccountByAccountNumber(String accountNumber) {
    	AccountDetails account = null;
        String query = "SELECT * FROM users WHERE account_number = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, accountNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                account = new AccountDetails();
                account.setId(rs.getInt("id"));
                account.setUsername(rs.getString("username"));
                account.setDateOfBirth(rs.getDate("date_of_birth").toLocalDate());
                account.setEmail(rs.getString("email"));
                account.setAccountNumber(rs.getString("account_number"));
                account.setAccountHolderName(rs.getString("account_holder_name"));
                account.setAccountType(rs.getString("account_type"));
                account.setBalance(rs.getDouble("balance"));
                account.setPhoneNumber(rs.getString("phone_number"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return account;
    }

    // Method to update account details in the database
    public boolean updateAccount(AccountList account) {
        String query = "UPDATE users SET account_holder_name = ?, account_type = ?, balance = ?, username = ?, date_of_birth = ?, email = ? WHERE account_number = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, account.getAccountHolderName());
            stmt.setString(2, account.getAccountType());
            stmt.setDouble(3, account.getBalance());
            stmt.setString(4, account.getUsername());
            stmt.setString(5, account.getDateofbirth());
            stmt.setString(6, account.getEmail());
            stmt.setString(7, account.getAccountNumber());

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0; // Return true if the account was successfully updated
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false; // Return false if the update failed
    }
    
    // Method to withdraw money
    public boolean withdrawMoney(Connection connection, String accountNumber, double amount) throws Exception {
        String selectQuery = "SELECT balance FROM users WHERE account_number = ?";
        String updateQuery = "UPDATE users SET balance = ? WHERE account_number = ?";
        
        try (PreparedStatement selectStmt = connection.prepareStatement(selectQuery)) {
            selectStmt.setString(1, accountNumber);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");

                // Check if sufficient balance exists
                if (currentBalance >= amount) {
                    try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                        updateStmt.setDouble(1, currentBalance - amount);
                        updateStmt.setString(2, accountNumber);
                        updateStmt.executeUpdate();
                    }
                    return true; // Success
                } else {
                    throw new Exception("Insufficient balance.");
                }
            } else {
                throw new Exception("Account not found.");
            }
        }
    }
    public double getBalance(String accountNumber) throws Exception {
        String sql = "SELECT balance FROM users WHERE account_number = ?";
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, accountNumber);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getDouble("balance");
            } else {
                throw new Exception("Account not found");
            }
        }
    }

    public void updateBalance(String accountNumber, double newBalance) throws Exception {
        String sql = "UPDATE users SET balance = ? WHERE account_number = ?";
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDouble(1, newBalance);
            pst.setString(2, accountNumber);
            pst.executeUpdate();
        }
    }
    // Method to deposit money into an account
    public boolean depositMoney(Connection connection, String accountNumber, double amount) throws Exception {
        String query = "UPDATE users SET balance = balance + ? WHERE account_number = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setDouble(1, amount); // Add the deposit amount to the current balance
            preparedStatement.setString(2, accountNumber); // Specify the account number

            int rowsUpdated = preparedStatement.executeUpdate(); // Execute the update query
            return rowsUpdated > 0; // Return true if at least one row was updated
        }
    }
    
    public boolean depositAmount(String accountNumber, double amount) {
        String query = "UPDATE users SET balance = balance + ? WHERE account_number = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDouble(1, amount);
            stmt.setString(2, accountNumber);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
