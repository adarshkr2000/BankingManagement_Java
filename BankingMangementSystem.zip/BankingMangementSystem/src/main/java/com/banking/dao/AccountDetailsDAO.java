package com.banking.dao;

import com.banking.model.AccountDetails;
import java.sql.*;

public class AccountDetailsDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Javaservelet@20";

    // Method to get account details by account number
    public AccountDetails getAccountDetailsByAccountNumber(String accountNumber) {
        String query = "SELECT * FROM users WHERE account_number = ?";
        AccountDetails accountDetails = null;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, accountNumber);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    accountDetails = new AccountDetails();
                    accountDetails.setId(rs.getInt("id"));
                    accountDetails.setUsername(rs.getString("username"));
                    accountDetails.setEmail(rs.getString("email"));
                    accountDetails.setAccountHolderName(rs.getString("account_holder_name"));
                    accountDetails.setDateOfBirth(rs.getDate("date_of_birth").toLocalDate());
                    accountDetails.setPhoneNumber(rs.getString("phone_number"));
                    accountDetails.setAccountType(rs.getString("account_type"));
                    accountDetails.setBalance(rs.getDouble("balance"));
                    accountDetails.setAccountNumber(rs.getString("account_number"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching account details: " + e.getMessage());
            e.printStackTrace();
        }

        return accountDetails;
    }
}
