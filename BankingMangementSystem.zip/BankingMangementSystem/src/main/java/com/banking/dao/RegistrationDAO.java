package com.banking.dao;
import java.sql.ResultSet;

import com.banking.model.Registration;
import com.bankingsystem.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistrationDAO {

    // Method to register a user
    public boolean registerUser(Registration registration) {
        boolean isRegistered = false;

        // SQL query to insert user data into the database
        String sql = "INSERT INTO users (username, email, password, account_holder_name, date_of_birth, phone_number, account_type, balance, account_number) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Establish a connection to the database
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            // Set the parameters for the SQL query
            preparedStatement.setString(1, registration.getUsername());
            preparedStatement.setString(2, registration.getEmail());
            preparedStatement.setString(3, registration.getPassword());
            preparedStatement.setString(4, registration.getAccountHolderName());
            preparedStatement.setDate(5, Date.valueOf(registration.getDateOfBirth()));
            preparedStatement.setString(6, registration.getPhoneNumber());
            preparedStatement.setString(7, registration.getAccountType());
            preparedStatement.setBigDecimal(8, registration.getBalance());
            preparedStatement.setString(9, registration.getAccountNumber());

            // Execute the update and check if the insertion was successful
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                isRegistered = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isRegistered;
    }
    public Registration getUserByUsername(String username) {
        Registration registration = null;
        String query = "SELECT * FROM users WHERE username = ?"; 

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
             
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                registration = new Registration();
                registration.setUsername(resultSet.getString("username"));
                registration.setEmail(resultSet.getString("email"));
                registration.setPassword(resultSet.getString("password"));
                registration.setAccountHolderName(resultSet.getString("account_holder_name"));
                registration.setDateOfBirth(resultSet.getString("date_of_birth"));
                registration.setPhoneNumber(resultSet.getString("phone_number"));
                registration.setAccountType(resultSet.getString("account_type"));
                registration.setBalance(resultSet.getBigDecimal("balance"));
                registration.setAccountNumber(resultSet.getString("account_number"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registration;
    }
}
