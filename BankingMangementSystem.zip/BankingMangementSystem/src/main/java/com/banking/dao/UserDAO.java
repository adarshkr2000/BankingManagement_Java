package com.banking.dao;

import com.banking.model.User;
import com.bankingsystem.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    public User getUserByUsername(String username) {
        User user = null;
        String query = "SELECT * FROM users WHERE username = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setAccountHolderName(rs.getString("account_holder_name"));
                user.setDateOfBirth(rs.getString("date_of_birth"));
                user.setPhoneNumber(rs.getString("phone_number"));
                user.setAccountType(rs.getString("account_type"));
                user.setBalance(rs.getDouble("balance"));
                user.setAccountNumber(rs.getString("account_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}
