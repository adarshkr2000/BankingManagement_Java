package com.banking.servlet;

import com.banking.dao.AccountListDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteAccount")
public class DeleteAccountServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the account number from the request parameter
        String accountNumber = request.getParameter("accountNumber");

        if (accountNumber != null) {
            // Initialize AccountListDAO to delete the account
            AccountListDAO dao = new AccountListDAO();

            // Call the delete method in the DAO (you will need to implement this method in the DAO)
            boolean isDeleted = dao.deleteAccount(accountNumber);

            // Check if deletion was successful
            if (isDeleted) {
                // Redirect to AccountListServlet to show updated account list
                response.sendRedirect("AccountListServlet");
            } else {
                // If deletion failed, send an error message
                request.setAttribute("errorMessage", "Failed to delete account.");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
            }
        } else {
            // If accountNumber is not provided, redirect to AccountListServlet
            response.sendRedirect("AccountListServlet");
        }
    }
}
