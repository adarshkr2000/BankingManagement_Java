package com.banking.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/TransferFundsServlet")
public class TransferFundsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Javaservelet@20";

    // Handle GET request to show the transfer form
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	 String accountNumber = request.getParameter("accountNumber");
         request.setAttribute("accountNumber", accountNumber);
    	request.getRequestDispatcher("transferFunds.jsp").forward(request, response);
    }

    // Handle POST request to perform the fund transfer
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fromAccount = request.getParameter("fromAccount");
        String toAccount = request.getParameter("toAccount");
        String amountStr = request.getParameter("amount");
        String description = request.getParameter("description");

        // Validate input data
        if (fromAccount == null || toAccount == null || amountStr == null || description == null) {
            request.setAttribute("message", "All fields are required.");
            request.getRequestDispatcher("transferFunds.jsp").forward(request, response);
            return;
        }

        double amount = 0;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            request.setAttribute("message", "Invalid amount format.");
            request.getRequestDispatcher("transferFunds.jsp").forward(request, response);
            return;
        }

        if (amount <= 0) {
            request.setAttribute("message", "Amount must be greater than zero.");
            request.getRequestDispatcher("transferFunds.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Disable auto-commit for transaction
            conn.setAutoCommit(false);

            // Deduct amount from sender's account
            PreparedStatement deductStmt = conn.prepareStatement(
                "UPDATE users SET balance = balance - ? WHERE account_number = ?");
            deductStmt.setDouble(1, amount);
            deductStmt.setString(2, fromAccount);
            int rowsDeducted = deductStmt.executeUpdate();

            // Add amount to receiver's account
            PreparedStatement addStmt = conn.prepareStatement(
                "UPDATE users SET balance = balance + ? WHERE account_number = ?");
            addStmt.setDouble(1, amount);
            addStmt.setString(2, toAccount);
            int rowsAdded = addStmt.executeUpdate();

            // Insert transaction record
            PreparedStatement logStmt = conn.prepareStatement(
                "INSERT INTO transactions (from_account, to_account, amount, description) VALUES (?, ?, ?, ?)");
            logStmt.setString(1, fromAccount);
            logStmt.setString(2, toAccount);
            logStmt.setDouble(3, amount);
            logStmt.setString(4, description);
            logStmt.executeUpdate();

            // Commit transaction if successful
            if (rowsDeducted > 0 && rowsAdded > 0) {
                conn.commit();
                request.setAttribute("message", "Funds transferred successfully!");
            } else {
                conn.rollback();
                request.setAttribute("message", "Transfer failed. Please check the account numbers.");
            }

        } catch (SQLException e) {
            // Rollback transaction in case of an error
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            request.setAttribute("message", "Error: " + e.getMessage());
        }

        // Redirect to the transfer page with a message
        request.setAttribute("accountNumber", fromAccount);
        request.getRequestDispatcher("transferFunds.jsp").forward(request, response);
    }
    
}
