package com.banking.servlet;

import com.banking.dao.AccountListDAO;
import com.banking.model.AccountDetails;
import com.banking.model.AccountList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet("/WithdrawServlet")
public class WithdrawServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankingdb_06";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Javaservelet@20";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accountNumber = request.getParameter("accountNumber");
        String amountStr = request.getParameter("amount");

        // Validate input
        if (accountNumber == null || accountNumber.trim().isEmpty()) {
            request.setAttribute("message", "Account number is required.");
            request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
            return;
        }

        if (amountStr == null || amountStr.trim().isEmpty()) {
            request.setAttribute("message", "Amount is required.");
            request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr.trim());
            if (amount <= 0) {
                request.setAttribute("message", "Amount must be greater than zero.");
                request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
                return;
            }
        } catch (NumberFormatException e) {
            request.setAttribute("message", "Invalid amount format. Please enter a valid number.");
            request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
            return;
        }

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            AccountListDAO dao = new AccountListDAO();

            try {
                // Withdraw money and update balance in database
                boolean isSuccessful = dao.withdrawMoney(connection, accountNumber, amount);

                if (isSuccessful) {
                    // Fetch updated account details after withdrawal
                    AccountDetails account = dao.getAccountByAccountNumber(accountNumber);
                    request.setAttribute("account", account);
                    request.setAttribute("message", "Withdrawal successful!");
                } else {
                    request.setAttribute("message", "Withdrawal failed. Insufficient balance.");
                }
            } catch (Exception e) {
                request.setAttribute("message", "Error during withdrawal: " + e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Database connection error.");
        }

        // Forward to account details page to show the updated information
        request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
    }
}
