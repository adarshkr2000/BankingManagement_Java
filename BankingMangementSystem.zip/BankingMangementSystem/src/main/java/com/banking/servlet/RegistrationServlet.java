package com.banking.servlet;

import com.banking.dao.RegistrationDAO;
import com.banking.model.Registration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;

@SuppressWarnings("serial")
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String accountHolderName = request.getParameter("accountHolderName");
        String dateOfBirth = request.getParameter("dateofbirth");
        String phoneNumber = request.getParameter("phoneNumber");
        String accountType = request.getParameter("accountType");
        BigDecimal balance = new BigDecimal(request.getParameter("balance"));

        // Validate password confirmation
        if (password != null && confirmPassword != null && password.equals(confirmPassword)) {
            Registration registration = new Registration();
            registration.setUsername(username);
            registration.setEmail(email);
            registration.setPassword(password); 
            registration.setAccountHolderName(accountHolderName);
            registration.setDateOfBirth(dateOfBirth);
            registration.setPhoneNumber(phoneNumber);
            registration.setAccountType(accountType);
            registration.setBalance(balance);
            registration.setAccountNumber(generateAccountNumber());

            RegistrationDAO dao = new RegistrationDAO();
            boolean isRegistered = dao.registerUser(registration);

            if (isRegistered) {
                request.setAttribute("successMessage", "Registration successful!");
                request.setAttribute("account", registration.getAccountNumber());
            } else {
                request.setAttribute("error", "Registration failed. Please try again.");
            }
        } else {
            request.setAttribute("error", "Passwords do not match.");
        }

        request.getRequestDispatcher("/success.jsp").forward(request, response);
    }

    // method to generate account number
    private String generateAccountNumber() {
        return "ACC" + System.currentTimeMillis();
    }
}
