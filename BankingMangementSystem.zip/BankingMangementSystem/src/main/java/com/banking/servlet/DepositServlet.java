package com.banking.servlet;

import com.banking.dao.AccountDetailsDAO;
import com.banking.dao.AccountListDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/DepositServlet")
public class DepositServlet extends HttpServlet {
    private AccountListDAO accountListDAO;

    @Override
    public void init() {
    	accountListDAO = new AccountListDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));

        boolean success = accountListDAO.depositAmount(accountNumber, amount);

        if (success) {
        	request.setAttribute("message", "Deposit successful!");
            response.sendRedirect("AccountDetailsServlet");
        } else {
            request.setAttribute("message", "Error processing transaction.");
            request.getRequestDispatcher("deposit.jsp").forward(request, response);
        }
    }
}
