package com.banking.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.banking.dao.AdminLoginDAO;
import com.banking.model.AdminModel;

import java.io.IOException;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        AdminLoginDAO adminDAO = new AdminLoginDAO();
        AdminModel account = adminDAO.validateAdminLogin(username, password);
        
        if (account != null) {
            HttpSession session = request.getSession(); // Create new session
            session.setAttribute("username", account.getUsername()); // Store username in session
            response.sendRedirect("Admindashboard.jsp");
        } else {
            request.setAttribute("errorMessage", "Invalid username or password.");
            request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);
        }
    }
}
