package com.banking.servlet;

import com.banking.dao.AccountDetailsDAO;
import com.banking.model.AccountDetails;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/AccountDetailsServlet")
public class AccountDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AccountDetailsDAO accountDetailsDAO;

    @Override
    public void init() {
        accountDetailsDAO = new AccountDetailsDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        AccountDetails accountDetailsFromSession=null;
        String accountNumber = null;

        if (session != null) {
        	accountDetailsFromSession = (AccountDetails) session.getAttribute("account");
        	accountNumber = accountDetailsFromSession.getAccountNumber();
        }

        if (accountNumber != null && !accountNumber.isEmpty()) {
            AccountDetails accountDetails = accountDetailsDAO.getAccountDetailsByAccountNumber(accountNumber);

            if (accountDetails != null) {
                request.setAttribute("account", accountDetails);
            } else {
                request.setAttribute("message", "No account found with account number: " + accountNumber);
            }
        } else {
            request.setAttribute("message", "Please log in to view account details.");
        }

        request.getRequestDispatcher("accountDetails.jsp").forward(request, response);
    }
}
