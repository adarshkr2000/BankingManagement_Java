package com.banking.servlet;

import com.banking.dao.AccountListDAO;
import com.banking.model.AccountList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/AccountListServlet")
public class AccountListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AccountListDAO accountListDAO;

    @Override
    public void init() {
        accountListDAO = new AccountListDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<AccountList> accounts = accountListDAO.getAllAccounts();

        // Set the accounts list as a request attribute
        request.setAttribute("accounts", accounts);

        // Forward to accountList.jsp to display the accounts
        request.getRequestDispatcher("accountList.jsp").forward(request, response);
    }
    
}
