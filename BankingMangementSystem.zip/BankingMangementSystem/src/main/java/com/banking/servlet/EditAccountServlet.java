package com.banking.servlet;

import com.banking.dao.AccountListDAO;
import com.banking.model.AccountDetails;
import com.banking.model.AccountList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/editAccount")
public class EditAccountServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");

        // Get the account details based on the account number
        AccountListDAO dao = new AccountListDAO();
        AccountDetails account = dao.getAccountByAccountNumber(accountNumber);

        if (account != null) {
            request.setAttribute("account", account);
            // Forward to the edit page
            request.getRequestDispatcher("editAccount.jsp").forward(request, response);
        } else {
            response.sendRedirect("AccountListServlet"); // Redirect to the account list if account not found
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");
        String accountHolderName = request.getParameter("accountHolderName");
        String accountType = request.getParameter("accountType");
        double balance = Double.parseDouble(request.getParameter("balance"));
        String username = request.getParameter("username");
        String dob = request.getParameter("date_of_birth");
        String email = request.getParameter("email");

        // Create AccountList object and set the updated values
        AccountList account = new AccountList();
        account.setAccountNumber(accountNumber);
        account.setAccountHolderName(accountHolderName);
        account.setAccountType(accountType);
        account.setBalance(balance);
        account.setUsername(username);
        account.setDateofbirth(dob);
        account.setEmail(email);

        // Update the account details in the database
        AccountListDAO dao = new AccountListDAO();
        boolean isUpdated = dao.updateAccount(account);

        if (isUpdated) {
            // Redirect to the account list page if the update is successful
            response.sendRedirect("AccountListServlet");
        } else {
            // Redirect to an error page if the update fails
            response.sendRedirect("error.jsp");
        }
    }
}
