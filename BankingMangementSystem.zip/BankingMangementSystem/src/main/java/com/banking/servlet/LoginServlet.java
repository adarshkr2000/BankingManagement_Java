package com.banking.servlet;

import com.banking.model.AccountDetails;
import com.banking.model.Login;
import com.banking.dao.LoginDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");
        String password = request.getParameter("password");

        AccountDetails account = LoginDAO.validateUser(accountNumber, password);

        if (account != null) {
            // Valid user, start session
            HttpSession session = request.getSession();
            session.setAttribute("account", account);
            

   
            RequestDispatcher rd= request.getRequestDispatcher("accountDetails.jsp");
            rd.forward(request, response);
        } else {
            // Invalid credentials
            request.setAttribute("message", "Invalid account number or password.");
            request.setAttribute("messageType", "danger");
            request.getRequestDispatcher("Login.jsp").forward(request, response);
        }
    }
}
