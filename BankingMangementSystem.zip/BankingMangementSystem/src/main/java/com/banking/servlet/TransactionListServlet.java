package com.banking.servlet;

import com.banking.dao.TransactionDAO;
import com.banking.model.Transaction;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/TransactionServlet")
public class TransactionListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        TransactionDAO transactionDAO = new TransactionDAO();
        List<Transaction> transactions = transactionDAO.getAllTransactions();

        // Set the transactions list as a request attribute
        request.setAttribute("transactions", transactions);

        // Forward to JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("transactionList.jsp");
        dispatcher.forward(request, response);
    }
}
